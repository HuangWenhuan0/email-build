#!/usr/bin/env python
# coding: utf-8

import os
import mbuild

def run():
    mbuild.main()

if __name__ == '__main__':
    print os.getcwd()
    run()